Before starting, just replace the section

	## replace me with your root
	root   C:\Users\MParcewski\workspace\SGX\clientv2;

with the path to your working directory.

To start, just click on nginx.exe in this directory.  

To stop, reload, etc... open up command prompt cd into this directory and run

	fast shutdown
		nginx -s stop	
	graceful shutdown
		nginx -s quit	
	changing configuration, starting new worker processes with a new configuration, graceful shutdown of old worker processes
		nginx -s reload